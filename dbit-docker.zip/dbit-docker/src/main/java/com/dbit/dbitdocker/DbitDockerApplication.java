package com.dbit.dbitdocker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbitDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbitDockerApplication.class, args);
	}

}
